export interface Posts{
  id_post?: string;
  titulo: string;
  fecha_publicacion: string;
  contenido: string;
  nickname_usuario: string
}