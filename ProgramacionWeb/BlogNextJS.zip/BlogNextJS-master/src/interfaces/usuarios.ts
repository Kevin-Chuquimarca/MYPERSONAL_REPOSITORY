export interface usuarios{
    id_usuarios?:string;
    nickname:string;
    email?:string;
    password:string;
    login?:string;
}